# Vampire-Lord
<h1 style="color:purple">The Snake</h1>
<hr>
<p><h2 style="color:purple">Developers <sup>TM</sup></h2> </p>
<p>
<hr>
	<ul style="list-style-type:disc">
	<li>Цветан Разсолков</li>
	<li>Георги Малковски </li>
	<li>Еса Вехманен </li>
	<li>Атанас Даченски </li>
	<li>Константина Кръстева</li>
	<li>Ивайло Парванов </li>
	<li>Янко Стоянов </li>
	<li>аа бб </li>
	</ul>  
	<hr>
</p>
