﻿namespace TeleimotBg.GlobalConstants
{
    using System;
    using System.Linq;

    public class AssembliesNames
    {
        public const string DataServices = "TeleimotBg.Services.Data";
        public const string WebApi = "TeleimotBg.Api";
    }
}
