﻿namespace TeleimotBg.GlobalConstants
{
    using System;
    using System.Linq;

    public class UtilityConstants
    {
        public const int DefaultTakeSize = 10;
        public const int DefaultSkipSize = 0;
    }
}
