﻿namespace TeleimotBg.Models
{
    using System;
    using System.Linq;

    public enum RealEstateType
    {
        Appartment = 0,
        House = 1,
        Office = 2,
        Storehouse = 3
    }
}
