﻿namespace TeleimotBg.Api.Infrastructure.Mappings
{
    using System;
    using System.Linq;

    public interface IMapFrom<TModel>
    {
    }
}
